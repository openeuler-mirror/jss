// --- BEGIN COPYRIGHT BLOCK ---
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; version 2 of the License.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License along
// with this program; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
//
// (C) 2007 Red Hat, Inc.
// All rights reserved.
// --- END COPYRIGHT BLOCK ---
package org.mozilla.jss.netscape.security.acl;

import java.security.Principal;

/**
 * This class implements a group of principals.
 *
 * @author Satish Dharmaraj
 * @deprecated GroupImpl in org.mozilla.jss.netscape.security.acl has been deprecated
 */
@Deprecated
public class WorldGroupImpl extends GroupImpl {

    /**
     * @deprecated GroupImpl in org.mozilla.jss.netscape.security.acl has been deprecated
     */
    @Deprecated
    public WorldGroupImpl(String s) {
        super(s);
    }

    /**
     * returns true for all passed principals
     *
     * @param member The principal whose membership must be checked in this Group.
     * @return true always since this is the "world" group.
     * @deprecated isMember(Principal) in GroupImpl has been deprecated
     */
    @Deprecated
    public boolean isMember(Principal member) {
        return true;
    }
}
